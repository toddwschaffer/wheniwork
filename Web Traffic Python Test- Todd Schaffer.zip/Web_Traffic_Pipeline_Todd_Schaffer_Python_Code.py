### PRODUCTION CODE
import pandas as pd
from datetime import datetime
url = "https://public.wiwdata.com/engineering-challenge/data/" 
files = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
file_list= []
for i in range(len(files)):
    file_list.append(url + files[i] + '.csv')

result = pd.DataFrame() ##iniitate a blank data frame to store the results

for i in range(len(file_list)): 
  
    df = pd.DataFrame(pd.read_csv(file_list[i])) ## push this to a Pandas DataFrame
    df['data_file'] = files[i]
    frames = [result, df] #store the result df and current df in a list
    
    
    result = pd.concat(frames) #concatenate the df with the results df
    
new_data = result.pivot_table(index='user_id', columns='path', values='length',aggfunc='sum').reset_index()
new_data = new_data.rename_axis(None, axis=1)
data_datetime = datetime.now()
new_data['run_date'] = data_datetime
new_data.to_excel ('C:\\users\\twschaff\\downloads\\web_traffic_pipeline.xlsx', sheet_name = "Todd Schaffer",
                index = False)